﻿using Microsoft.AspNetCore.Mvc.ModelBinding.Validation;

namespace WebApplication5.Models
{
	public class University
	{
		public int Id { get; set; }
		public string Name { get; set; }
		public string Description { get; set; }

	
		[ValidateNever]
		public List<Student> Students { get; set; }
	}
}
