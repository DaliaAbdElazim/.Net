﻿using Microsoft.AspNetCore.Mvc.ModelBinding.Validation;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel;

namespace WebApplication5.Models
{
	public class Student
	{
		public int Id { get; set; }

	
		[DisplayName("Name")]
		[Required(ErrorMessage = "You have to provide a valid full name.")]
		[MinLength(12, ErrorMessage = "Full name mustn't be less than 12 characters.")]
		[MaxLength(70, ErrorMessage = "Full name mustn't exceepd 70 characters.")]
		public string FullName { get; set; }

		

		[DisplayName("Date of Birth")]
		public DateTime BirthDate { get; set; }

		[DisplayName("Date of Join")]
		public DateTime JoinDate { get; set; }

		[DisplayName("Image")]
		[ValidateNever]
		public string ImageUrl { get; set; }

		[Range(1, int.MaxValue, ErrorMessage = "Choose a valid UniversityId.")]
		[DisplayName("University ")]
		public int UniversityId { get; set; }


		[ValidateNever]
		public University University { get; set; }
	}
}
