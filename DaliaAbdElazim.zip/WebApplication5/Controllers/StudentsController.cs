﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using WebApplication5.Data;
using WebApplication5.Models;

namespace WebApplication5.Controllers
{
    public class StudentsController : Controller
    {
        IWebHostEnvironment _webHostEnvironment;
        ApplicationDbContext _context;

        public StudentsController(IWebHostEnvironment webHostEnvironment, ApplicationDbContext context)
        {
            _webHostEnvironment = webHostEnvironment;
            _context = context;
        }

        public string greet()
        {
            return "welcome";
        }
        [HttpGet]
        public IActionResult GetIndexView()
        {
            return View("Index", _context.Student.ToList());
        }

        [HttpGet]
        public IActionResult GetDetailsView(int id)
        {
            Student student = _context.Student.Include(e => e.University).FirstOrDefault(e => e.Id == id);

            return View("Details", student);
        }

        [HttpGet]
        public IActionResult GetCreateView()
        {
            ViewBag.DeptSelectItems = new SelectList(_context.University.ToList(), "Id", "Name");
            return View("Create");
        }

        [HttpPost]
        public IActionResult AddNew(Student student, IFormFile? imageFormFile)
        {
          
            if (imageFormFile != null)
            {
                string imgExtension = Path.GetExtension(imageFormFile.FileName); 
                Guid imgGuid = Guid.NewGuid(); 
                string imgName = imgGuid + imgExtension; 
                string imgUrl = "\\images\\" + imgName; 
                student.ImageUrl = imgUrl;

                string imgPath = _webHostEnvironment.WebRootPath + imgUrl;

                FileStream imgStream = new FileStream(imgPath, FileMode.Create);
                imageFormFile.CopyTo(imgStream);
                imgStream.Dispose();
            }
            else
            {
                student.ImageUrl = "\\images\\No_Image.png";
            }

            if (((student.JoinDate - student.BirthDate).Days / 365) < 18)
            {
                ModelState.AddModelError(string.Empty, "Illegal Hiring Age (Under 18 years old).");
            }

            

            if (ModelState.IsValid == true)
            {
                _context.Student.Add(student);
                _context.SaveChanges();
                return RedirectToAction("GetIndexView");
            }
            else
            {
                ViewBag.DeptSelectItems = new SelectList(_context.University.ToList(), "Id", "Name");
                return View("Create");
            }
        }


        [HttpGet]
        public IActionResult GetEditView(int id)
        {
            Student student = _context.Student.FirstOrDefault(e => e.Id == id);

            if (student == null)
            {
                return NotFound();
            }
            else
            {
                ViewBag.DeptSelectItems = new SelectList(_context.University.ToList(), "Id", "Name");
                return View("Edit", student);
            }
        }


        [HttpPost]
        public IActionResult EditCurrent(Student emp, IFormFile? imageFormFile)
        {
         
            if (imageFormFile != null)
            {
                if (emp.ImageUrl != "\\images\\No_Image.png")
                {
                    string oldImgPath = _webHostEnvironment.WebRootPath + emp.ImageUrl;

                    if (System.IO.File.Exists(oldImgPath) == true)
                    {
                        System.IO.File.Delete(oldImgPath);
                    }
                }


                string imgExtension = Path.GetExtension(imageFormFile.FileName);
                Guid imgGuid = Guid.NewGuid(); 
                string imgName = imgGuid + imgExtension;
                string imgUrl = "\\images\\" + imgName;
                emp.ImageUrl = imgUrl;

                string imgPath = _webHostEnvironment.WebRootPath + imgUrl;

                // FileStream 
                FileStream imgStream = new FileStream(imgPath, FileMode.Create);
                imageFormFile.CopyTo(imgStream);
                imgStream.Dispose();
            }




            if (((emp.JoinDate - emp.BirthDate).Days / 365) < 18)
            {
                ModelState.AddModelError(string.Empty, "Illegal Hiring Age (Under 18 years old).");
            }

            if (ModelState.IsValid == true)
            {
                _context.Student.Update(emp);
                _context.SaveChanges();
                return RedirectToAction("GetIndexView");
            }
            else
            {
                ViewBag.DeptSelectItems = new SelectList(_context.University.ToList(), "Id", "Name");
                return View("Edit");
            }
        }


        [HttpGet]
        public IActionResult GetDeleteView(int id)
        {
            Student student = _context.Student.Include(e => e.University).FirstOrDefault(e => e.Id == id);

            if (student == null)
            {
                return NotFound();
            }
            else
            {
                return View("Delete", student);
            }
        }


        [HttpPost]
        public IActionResult DeleteCurrent(int id)
        {
            Student student = _context.Student.FirstOrDefault(e => e.Id == id);
            if (student == null)
            {
                return NotFound();
            }
            else
            {
                if (student.ImageUrl != "\\images\\No_Image.png")
                {
                    string imgPath = _webHostEnvironment.WebRootPath + student.ImageUrl;

                    if (System.IO.File.Exists(imgPath))
                    {
                        System.IO.File.Delete(imgPath);
                    }
                }


                _context.Student.Remove(student);
                _context.SaveChanges();
                return RedirectToAction("GetIndexView");
            }
        }
    }
}
