﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using WebApplication5.Data;
using WebApplication5.Models;

namespace WebApplication5.Controllers
{
    public class UniveritiesController : Controller
    {
        ApplicationDbContext _context;
        public UniveritiesController(ApplicationDbContext context)
        {
            _context = context;
        }


        [HttpGet]
        public IActionResult GetIndexView()
        {
            return View("Index", _context.University.ToList());
        }

        [HttpGet]
        public IActionResult GetDetailsView(int id)
        {
            University department = _context.University.Include(d => d.Students).FirstOrDefault(e => e.Id == id);

            return View("Details", department);
        }

        [HttpGet]
        public IActionResult GetCreateView()
        {
            return View("Create");
        }

        [HttpPost]
        public IActionResult AddNew(University university) // FolanAlfolani.png
        {
            if (ModelState.IsValid == true)
            {
                _context.University.Add(university);
                _context.SaveChanges();
                return RedirectToAction("GetIndexView");
            }
            else
            {
                return View("Create");
            }
        }


        [HttpGet]
        public IActionResult GetEditView(int id)
        {
            University university = _context.University.FirstOrDefault(e => e.Id == id);

            if (university == null)
            {
                return NotFound();
            }
            else
            {
                return View("Edit", university);
            }
        }


        [HttpPost]
        public IActionResult EditCurrent(University university)
        {
            if (ModelState.IsValid == true)
            {
                _context.University.Update(university);
                _context.SaveChanges();
                return RedirectToAction("GetIndexView");
            }
            else
            {
                return View("Edit");
            }
        }


        [HttpGet]
        public IActionResult GetDeleteView(int id)
        {
            University university = _context.University.Include(d => d.Students).FirstOrDefault(e => e.Id == id);

            if (university == null)
            {
                return NotFound();
            }
            else
            {
                return View("Delete", university);
            }
        }


        [HttpPost]
        public IActionResult DeleteCurrent(int id)
        {
            University university = _context.University.FirstOrDefault(e => e.Id == id);
            if (university == null)
            {
                return NotFound();
            }
            else
            {
                _context.University.Remove(university);
                _context.SaveChanges();
                return RedirectToAction("GetIndexView");
            }
        }

    }

}
